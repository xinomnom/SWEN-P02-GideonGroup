﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SWENWindowForm
{
    public partial class StaffManagementU : Form
    {
        public StaffManagementU()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=SWENDatabase;Integrated Security=True ");

        private void button2_Click(object sender, EventArgs e)//Back
        {
            this.Hide();
            StaffManagementH ss = new StaffManagementH();
            ss.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)//Update
        {
            con.Open();
            string query = "UPDATE Staff SET Staff_FirstName = '"+textBox1.Text +"',Staff_LastName='"+ textBox2.Text+  "',Staff_Address='" + textBox7.Text + "',Staff_ContactNumber='" + textBox6.Text + "',Staff_NRIC='" + textBox3.Text + "',Staff_DOB='" + textBox4.Text + "',Staff_Salary='" + textBox10.Text + "',Staff_BankNo='" + textBox11.Text + "',Staff_PostalCode='" + textBox8.Text + "',Staff_Country='" + comboBox2.Text + "',Staff_Email='" + textBox5.Text + "',Staff_Duty='"+comboBox1.Text+"' ";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Staff Updated!");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)//First name
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)//Last name
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)//NRIC
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)//DOB
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)//Email
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)//Contact number
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)//Country
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)//Address
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)//Postal Code
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)//Duty
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)//Salary
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)//Bank account
        {

        }

        private void StaffManagementU_Load(object sender, EventArgs e)
        {

        }
    }
}
