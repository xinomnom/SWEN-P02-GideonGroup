﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SWENWindowForm
{
    public partial class StaffManagementC : Form
    {
        public StaffManagementC()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=SWENDatabase;Integrated Security=True ");

        private void button2_Click(object sender, EventArgs e)//Back
        {
            this.Hide();
            StaffManagementH ss = new StaffManagementH();
            ss.Show();
        }

        private void button1_Click(object sender, EventArgs e)//Submit
        {
            con.Open();
            String query = "INSERT INTO Staff(Staff_FirstName,Staff_LastName, Staff_Address,Staff_ContactNumber,Staff_NRIC,Staff_DOB,Staff_Salary,Staff_BankNo,Staff_PostalCode,Staff_Country,Staff_Email,Staff_Duty) VALUES ('"+textBox1.Text+ "','" + textBox2.Text + "','" + textBox7.Text + "','" + textBox6.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox8.Text + "','" + comboBox1.Text + "','" + textBox5.Text + "','" + comboBox2.Text + "') ";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Insert Success");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)//First name
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)//Last name
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)//NRIC
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)//DOB
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)//Email
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)//Contact number
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)//Country
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)//Address
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)//postal code
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)//duty
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)//Salary
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)//Bank account
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
