﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SWENWindowForm
{
    public partial class StaffManagementH : Form
    {
        public StaffManagementH()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=SWENDatabase;Integrated Security=True ");


        private void button6_Click(object sender, EventArgs e)//update
        {
            //this.Hide();
            //StaffManagementU ss = new StaffManagementU();
            // ss.Show();

            con.Open();
            string query = "UPDATE Staff SET Staff_FirstName = '" + textBox9.Text + "',Staff_LastName='" + textBox2.Text + "',Staff_Address='" + textBox7.Text + "',Staff_ContactNumber='" + textBox6.Text + "',Staff_NRIC='" + textBox3.Text + "',Staff_DOB='" + textBox4.Text + "',Staff_Salary='" + textBox10.Text + "',Staff_BankNo='" + textBox11.Text + "',Staff_PostalCode='" + textBox8.Text + "',Staff_Country='" + comboBox2.Text + "',Staff_Email='" + textBox5.Text + "',Staff_Duty='" + comboBox1.Text + "' ";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Staff Updated!");




        }

        private void button3_Click(object sender, EventArgs e)//create
        {
            this.Hide();
            StaffManagementC ss = new StaffManagementC();
            ss.Show();
        }

        private void button4_Click(object sender, EventArgs e)//delete
        {
            //con.Open();
            //String query="DELETE FROM Staff where Id='"+textBox13.Text+"'";
            //SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            //SDA.SelectCommand.ExecuteNonQuery();
            //con.Close();
            //MessageBox.Show("Record Deleted");
           

        }

        private void StaffManagementH_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sWENDatabaseDataSet.Staff' table. You can move, or remove it, as needed.
            this.staffTableAdapter.Fill(this.sWENDatabaseDataSet.Staff);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void textBox9_TextChanged(object sender, EventArgs e)//FirstName
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)//search ID
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)//SearchButton
        {

            // SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM Staff WHERE Staff_ID" + textBox13.Text, con);
            DataTable dt = new DataTable();
            SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM Staff where Staff_ID =" + int.Parse(textBox13.Text), con);
            SDA.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button7_Click(object sender, EventArgs e)//Display All button
        {
            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=.;Initial Catalog=SWENDatabase;Integrated Security=True ");
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.SqlClient.SqlDataAdapter SDA = new System.Data.SqlClient.SqlDataAdapter("SELECT * from Staff", con);
            SDA.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)//double click to update
        {

            textBox9.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox7.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            textBox10.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
            textBox11.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            textBox8.Text = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
            comboBox2.Text = dataGridView1.SelectedRows[0].Cells[10].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[11].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[12].Value.ToString();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)//DOB
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)//Last Name
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)//NRIC
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)//Email
        {

        }
        private void textBox6_TextChanged(object sender, EventArgs e)//Contact Number
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)//Country
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)//Address
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)//Postal Code
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)//Duty
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)//Salary
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)//Bank a/n
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
