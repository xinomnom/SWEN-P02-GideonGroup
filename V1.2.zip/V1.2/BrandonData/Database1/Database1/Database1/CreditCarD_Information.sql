﻿CREATE TABLE [dbo].[CreditCard_Information]
(
	[Credit_ID] INT NOT NULL PRIMARY KEY, 
    [CreditCard_Number] VARCHAR(50) NOT NULL, 
    [Card_Owner] VARCHAR(50) NOT NULL, 
    [Expiration_Date] DATE NOT NULL, 
    [CVV_Number] INT NOT NULL
)
