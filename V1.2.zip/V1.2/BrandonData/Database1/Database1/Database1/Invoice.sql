﻿CREATE TABLE [dbo].[Invoice]
(
	[Invoice_ID] INT NOT NULL PRIMARY KEY, 
    [Status] VARCHAR(50) NOT NULL, 
    [Description] VARCHAR(50) NOT NULL, 
    [Bill_ID] INT NOT NULL, 
    CONSTRAINT [FK_Invoice_ToTable] FOREIGN KEY ([Bill_ID]) REFERENCES [Bill]([Bill_ID])
)
