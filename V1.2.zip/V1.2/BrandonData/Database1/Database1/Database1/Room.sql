﻿CREATE TABLE [dbo].[Room]
(
	[Room_ID] INT NOT NULL PRIMARY KEY, 
    [Room_Size] VARCHAR(50) NOT NULL, 
    [Room_TotalOccupantsNo] INT NOT NULL, 
    [AdultsNumber] INT NOT NULL, 
    [ChildNumber] INT NOT NULL, 
    [Room_Price] DECIMAL NOT NULL, 
    [Room_location] VARCHAR(50) NOT NULL, 
    [Guest_ID] INT NOT NULL, 
    CONSTRAINT [FK_Room_ToTable] FOREIGN KEY ([Guest_ID]) REFERENCES [Guest]([Guest_ID])
)
