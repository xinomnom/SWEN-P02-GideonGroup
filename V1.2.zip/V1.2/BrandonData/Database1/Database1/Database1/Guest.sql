﻿CREATE TABLE [dbo].[Guest]
(
	[Guest_ID] INT NOT NULL PRIMARY KEY, 
    [Guest_FirstName] VARCHAR(50) NOT NULL, 
    [Guest_LastName] VARCHAR(50) NOT NULL, 
    [Guest_Age] INT NOT NULL, 
    [Guest_DOB] DATE NOT NULL, 
    [Guest_Address] VARCHAR(50) NOT NULL, 
    [Guest_Country] VARCHAR(50) NOT NULL, 
    [Guest_PostalCode] VARCHAR(50) NOT NULL, 
    [Guest_Email] VARCHAR(50) NULL, 
   
)
