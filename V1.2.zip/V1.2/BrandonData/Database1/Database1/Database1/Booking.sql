﻿CREATE TABLE [dbo].[Booking]
(
	[Booking_ID] INT NOT NULL PRIMARY KEY, 
    [Booking_StartDate] DATETIME NOT NULL, 
    [Booking_EndDate] DATETIME NOT NULL, 
    [Booking_Extention] VARCHAR(50) NULL, 
    [Room_ID] INT NOT NULL, 
    [Customer_ID] INT NOT NULL, 
    CONSTRAINT [FK_Booking_ToTable] FOREIGN KEY ([Room_ID]) REFERENCES [Room]([Room_ID]), 
    CONSTRAINT [FK_Booking_ToTable_1] FOREIGN KEY ([Customer_ID]) REFERENCES [Customer]([Customer_ID])
)
