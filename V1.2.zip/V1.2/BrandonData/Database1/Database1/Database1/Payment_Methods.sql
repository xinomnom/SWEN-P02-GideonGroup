﻿CREATE TABLE [dbo].[Payment_Methods]
(
	[PaymentMethod_ID] INT NOT NULL PRIMARY KEY, 
    [In_Cash] INT NULL, 
    [Credit_ID] INT NOT NULL, 
    CONSTRAINT [FK_Payment_Methods_ToTable] FOREIGN KEY ([Credit_ID]) REFERENCES [CreditCard_Information]([Credit_ID])
)
