﻿CREATE TABLE [dbo].[Bill]
(
	[Bill_ID] INT NOT NULL PRIMARY KEY, 
    [Price_Of_Consumptions] DECIMAL NULL, 
    [No_Of_Nights_Stayed] INT NOT NULL, 
    [Room_Price] DECIMAL NOT NULL, 
    [Total_Price] DECIMAL NOT NULL
)
