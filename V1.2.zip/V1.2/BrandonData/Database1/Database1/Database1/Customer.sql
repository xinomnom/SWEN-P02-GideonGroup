﻿CREATE TABLE [dbo].[Customer]
(
	[Customer_ID] INT NOT NULL PRIMARY KEY, 
    [Customer_NRIC] VARCHAR(50) NOT NULL, 
    [Customer_FirstName] VARCHAR(50) NOT NULL, 
    [Customer_LastName] VARCHAR(50) NOT NULL, 
    [Customer_Age] INT NOT NULL, 
    [Customer_DOB] DATE NOT NULL, 
    [Customer_Address] VARCHAR(50) NOT NULL, 
    [Customer_Country] VARCHAR(50) NOT NULL, 
    [Customer_PostalCode] INT NOT NULL, 
    [Customer_Email] VARCHAR(50) NULL, 
    [Customer_Requests] VARCHAR(50) NULL, 
    [Booking_ID] INT NOT NULL, 
    [Invoice_ID] INT NOT NULL, 
    [PaymentMethod_ID] INT NOT NULL, 
    CONSTRAINT [FK_Customer_ToTable] FOREIGN KEY ([Booking_ID]) REFERENCES [Booking]([Booking_ID]), 
    CONSTRAINT [FK_Customer_ToTable_1] FOREIGN KEY ([Invoice_ID]) REFERENCES [Invoice]([Invoice_ID]), 
    CONSTRAINT [FK_Customer_ToTable_2] FOREIGN KEY ([PaymentMethod_ID]) REFERENCES [Payment_Methods]([PaymentMethod_ID])
)
