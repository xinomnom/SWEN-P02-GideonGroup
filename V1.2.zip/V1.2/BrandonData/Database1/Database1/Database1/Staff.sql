﻿CREATE TABLE [dbo].[Staff]
(
	[Staff_ID] INT NOT NULL PRIMARY KEY, 
    [Staff_FirstName] VARCHAR(50) NULL, 
    [Staff_LastName] VARCHAR(50) NULL, 
    [Staff_Address] VARCHAR(50) NULL, 
    [Staff_ContactNumber] INT NULL, 
    [Staff_NRIC] VARCHAR(50) NULL, 
    [Staff_DOB] VARCHAR(50) NULL, 
    [Staff_Salary] VARCHAR(50) NULL, 
    [Staff_BankNo] VARCHAR(50) NULL, 
    [Staff_PostalCode] INT NULL, 
    [Staff_Country] VARCHAR(50) NULL, 
    [Staff_Email] VARCHAR(50) NULL, 
    [Staff_Duty] VARCHAR(50) NULL, 
   
)
