# SWEN-P02-GideonGroup
Gideon - Only consists of staff management module
